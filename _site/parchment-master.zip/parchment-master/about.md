---
layout: default
title: About Me
---

<img class="profile-picture" src="{{site.baseurl}}/{{site.profile-picture}}">

I'm Dilbert. I've been working as a Software Engineer for over 30 years. I like to innovate to solve challenging problems using technology. I work with a great Engineering team, but we have a good-for-nothing and clueless manager, who can be replaced with a monkey and the change would be for the better.

On a personal front, I live with two amazing pets - Dogbert and Ratbert, and three dinasours - Bob, Rex and Dawn - who're hiding from the rest of the world. I'm single and have few friends due to my poor social skills, but I usually spend my time playing with computers and technology.

### Life Advice
Here are a few things I've learned over the years,
> An optimist is simply a pessimist with no job experience.

> All of your co-workers are fools. You must learn to pity and tolerate them.

> There are very few problems that can't be solved through a suitable application of high explosives.

### Publications
1. Dilbert, Ratbert: "Effects of having a dog and a dinasaur in the same house", _Journal of Wierd Studies_
2. Alice, Dilbert, Wally: "Efficient ways to deal with a dumb manager", _Conference of Frustrated Engineers_

### Contact Me
No thanks, I have enough problems of my own to deal with.
