---
layout: post
title: Sample draft
subtitle: This is a draft - it won't be visible on the blog
tags: [WIP]
---

Once the draft is complete, it should be moved to `_posts/` directory to see it on the blog